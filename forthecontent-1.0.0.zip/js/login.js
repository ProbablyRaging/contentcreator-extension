document.addEventListener('DOMContentLoaded', async () => {
    checkLoginPage();
});

function checkLoginPage() {
    let retries = 0;
    function reCheck() {
        if (retries < 30) {
            const pageName = document.querySelector('page-content').getAttribute('page');
            if (pageName === 'login') {
                setupLoginPage();
            } else {
                setTimeout(reCheck, 100);
            }
        }
    }
    reCheck();
}

function setupLoginPage() {
    setTimeout(() => {
        $('.content').animate({ opacity: 1 }, 300);
    }, 570);

    const authButton = document.getElementById('discordAuth');
    authButton.addEventListener('click', function () {
        chrome.runtime.sendMessage({ login: true }, () => { if (chrome.runtime.lastError) return; });
        authButton.innerHTML = 'Authenticating..';
        authButton.disabled = true;
    });

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.success) {
            const body = document.body;
            $('.body-bg').animate({ 'background-position-y': '-90px' }, 300);
            setTimeout(() => {
                $(body).animate({ opacity: 0 }, 300).promise().then(() => {
                    window.location = '../views/loader.html';
                    $(body).animate({ opacity: 1 }, 300);
                });
            }, 300);
        } else {
            authButton.innerHTML = 'Login via Discord';
            authButton.disabled = false;
        }
    });
}